package com.example.LeaveManagementSystem;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.example.LeaveManagementSystem.beanclasses.Department;
import com.example.LeaveManagementSystem.beanclasses.Employee;
import com.example.LeaveManagementSystem.bussiness.ValidateEmployee;

@Controller
@RequestMapping("adminoperations")
public class AdminOperationsController {
	@Autowired
	RestURL restURI;
	@RequestMapping(value = "addemployee", method = RequestMethod.POST)
	public String addEmployee(HttpSession session2, Employee employee,
			@RequestParam(name = "department") String department) {
		ValidateEmployee validateEmployee = new ValidateEmployee();
		Department department2 = new Department();
		department2.setDepartmentId(department);
		employee.setDepartment(department2);
		if (validateEmployee.emailValidation(employee.getEmail())) {
			if (validateEmployee.validatephonenumber(employee.getPhonenumber())) {
				String uri = restURI.getURL()+"/adminrest/createemployee";
				RestTemplate restTemplate = new RestTemplate();
				String result = restTemplate.postForObject(uri, employee, String.class);
				if (result.equals("added")) {
					session2.setAttribute("addemployee", "added");
					return "redirect:/addemployee.jsp";
				} else {
					session2.setAttribute("addemployee", "notadded");
					return "redirect:/addemployee.jsp";
				}

			} else {
				session2.setAttribute("addemployee", "contact");
				return "redirect:/addemployee.jsp";
			}
		} else {
			session2.setAttribute("addemployee", "email");
			return "redirect:/addemployee.jsp";
		}
	}

	@RequestMapping(value = "adddepartment", method = RequestMethod.POST)
	public String addDepartment(HttpSession session1, Department department) {
		String uri = restURI.getURL()+"/adminrest/adddepartment/" + department.getDepartmentId() + "/"
				+ department.getManagerId().getEmployeeId();
		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);
		if (result.equals("added"))
			session1.setAttribute("add", "added");
		return "redirect:/adddepartment.jsp";
	}

	@RequestMapping(value = "viewDepartment", method = RequestMethod.GET)
	public ModelAndView viewDepartment() {
		String uri = restURI.getURL()+"/adminrest/viewdepartment";
		RestTemplate restTemplate = new RestTemplate();
		ArrayList<String> result = restTemplate.getForObject(uri, ArrayList.class);
		ModelAndView model = new ModelAndView("viewdepartment");
		model.addObject("viewdepartment",result);
		return model;
	}

	@RequestMapping(value = "edit", method = RequestMethod.POST)
	public String editDetails(Employee employee) {
		ValidateEmployee ve = new ValidateEmployee();
		if (!employee.getEmployeeId().isEmpty()) {
			if (!employee.getAddress().isEmpty()) {
				String uri =restURI.getURL()+"/adminrest/editaddress/" + employee.getAddress() + "/"
						+ employee.getEmployeeId();
				RestTemplate rt = new RestTemplate();
				String s = rt.getForObject(uri, String.class);
			}
			if (!employee.getEmail().isEmpty()) {
				if (ve.emailValidation(employee.getEmail())) {
					String uri =restURI.getURL()+"/adminrest/editemail/" + employee.getEmail() + "/"
							+ employee.getEmployeeId();
					RestTemplate rt = new RestTemplate();
					String s = rt.getForObject(uri, String.class);
				}
			}
			if (!employee.getPhonenumber().isEmpty()) {
				if (ve.validatephonenumber(employee.getPhonenumber())) {
					String uri =restURI.getURL()+"/adminrest/editcontact/" + employee.getPhonenumber() + "/"
							+ employee.getEmployeeId();
					RestTemplate rt = new RestTemplate();
					String s = rt.getForObject(uri, String.class);
				}
			} else {
				return "redirect:/editEmployee.jsp";
			}
		} else {
			return "redirect:/editEmployee.jsp";
		}
		return "ok";
	}

}
